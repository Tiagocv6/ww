const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-Rp. 10 > Acessar recursos ViP
-Rp. 20 > Recursos VIP + Insira o bot no seu grupo!

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/554497462158 ou digite *${prefix}owner*_

*NOTA*
meninas mandem plaquinha pro pai q ganha o acesso vip de graca 🥵😎
}
exports.daftarvip = daftarvip
